import sys
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
        
    try:
         year, month, day, temp = line.split(',')
         temp = float(temp)
         print str(year)+'\t'+str(temp)+'\t'+"1"
    except ValueError:
         continue
